## Earth Data Kit

Contains modules to ease working with Geospatial Data.

## Warning
### This project is under active development.

**If you wish to contribute please reach out on siddhantgupta3@gmail.com**

Checkout the [docs](https://earth-data-kit.github.io/) for more details.

Check out the [Roadmap](https://earth-data-kit.github.io/roadmap.html).
ENGINES_SUPPORTED = ["s3", "earth_engine"]
GDALWARP_OPTS_SUPPORTED = ["-t_srs", "-tr", "-r"]
